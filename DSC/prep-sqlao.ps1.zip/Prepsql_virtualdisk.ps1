﻿#
# Copyright="© Microsoft Corporation. All rights reserved."
#

configuration PrepSQLVirtualDisk
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
		
		[Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLServicecreds,

        [UInt32]$DatabaseEnginePort = 1433,

        [Parameter(Mandatory)]
        [UInt32]$NumberOfDisks,

        [Parameter(Mandatory)]
        [String]$WorkloadType,

        [String]$DomainNetbiosName=(Get-NetBIOSName -DomainName $DomainName),

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

  	wusa /uninstall /kb:3186539  /quiet /norestart
	$source = "http://download.microsoft.com/download/F/9/4/F942F07D-F26F-4F30-B4E3-EBD54FABA377/NDP462-KB3151800-x86-x64-AllOS-ENU.exe"
	$dest = "C:\WindowsAzure\NDP462-KB3151800-x86-x64-AllOS-ENU.exe"
	Invoke-WebRequest $source -OutFile $dest
	$proc = Start-Process -FilePath "C:\WindowsAzure\NDP462-KB3151800-x86-x64-AllOS-ENU.exe" -ArgumentList "/quiet /norestart /log C:\WindowsAzure\NDP462-KB3151800-x86-x64-AllOS-ENU_install.log" -PassThru -Wait
	Import-DSCResource -Module xSystemSecurity -Name xIEEsc
    Import-DscResource -ModuleName xComputerManagement,CDisk,xActiveDirectory,XDisk,xSql, xSQLServer, xSQLps,xNetworking, SqlServerDSC
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
	[System.Management.Automation.PSCredential]$SQLCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($SQLServicecreds.UserName)", $SQLServicecreds.Password)
	New-StoragePool –FriendlyName SQLPool –StorageSubsystemFriendlyName "Storage Spaces*" -PhysicalDisks (Get-PhysicalDisk -CanPool $True)
	$Disks = Get-StoragePool –FriendlyName SQLPool -IsPrimordial $False | Get-PhysicalDisk
	New-Volume -StoragePoolFriendlyName "SQLPool" -FriendlyName "SQLFullText" -Size 100GB –NumberOfColumns $Disks.Count -ResiliencySettingName "Simple" -FileSystem NTFS -AccessPath "H:" -ProvisioningType Thin
	New-Volume -StoragePoolFriendlyName "SQLPool" -FriendlyName "SQLTemp" -Size 80GB –NumberOfColumns $Disks.Count -ResiliencySettingName "Simple" -FileSystem NTFS -AccessPath "K:" -ProvisioningType Thin
	New-Volume -StoragePoolFriendlyName "SQLPool" -FriendlyName "Backup" -Size 300GB –NumberOfColumns $Disks.Count -ResiliencySettingName "Simple" -FileSystem NTFS -AccessPath "L:" -ProvisioningType Thin
	New-Volume -StoragePoolFriendlyName "SQLPool" -FriendlyName "LDF" -Size 100GB –NumberOfColumns $Disks.Count -ResiliencySettingName "Simple" -FileSystem NTFS -AccessPath "G:" -ProvisioningType Thin
	New-Volume -StoragePoolFriendlyName "SQLPool" -FriendlyName "MDF" -Size 300GB –NumberOfColumns $Disks.Count -ResiliencySettingName "Simple" -FileSystem NTFS -AccessPath "F:" -ProvisioningType Thin
	Start-Process -Wait -FilePath "C:\SQLServer_13.0_Full\setup.exe" -ArgumentList "/ACTION=Uninstall /FEATURES=SQL,AS,RS /INSTANCENAME=MSSQLSERVER /Q /HIDECONSOLE"



    $RebootVirtualMachine = $false

    if ($DomainName)
    {
        $RebootVirtualMachine = $true
    }

    #Finding the next avaiable disk letter for Add disk

		

	Node localhost
    {


        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }

        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
	        DependsOn = "[WindowsFeature]ADPS"
        }
        
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
	        DependsOn = "[xWaitForADDomain]DscForestWait"
        }

		
		xIEEsc EnableIEEscAdmin

		{

			IsEnabled = $False

			UserRole  = "Administrators"

		}

		xIEEsc EnableIEEscUser

		{

			IsEnabled = $True

			UserRole  = "Users"

		}
		
		 SqlSetup 'InstallNamedInstance-WK01'
        {
            InstanceName          = 'WK01'
            Features              = 'SQLENGINE'
            SQLCollation          = 'SQL_Latin1_General_CP1_CI_AS'
            InstallSharedDir      = 'C:\Program Files\Microsoft SQL Server'
            InstallSharedWOWDir   = 'C:\Program Files (x86)\Microsoft SQL Server'
            InstanceDir           = 'C:\Program Files\Microsoft SQL Server'
            InstallSQLDataDir     = 'C:\Program Files\Microsoft SQL Server\MSSQL13.INST2016\MSSQL\Data'
            SQLUserDBDir          = 'F:\Data'
            SQLUserDBLogDir       = 'G:\Logs'
            SQLTempDBDir          = 'K:\TempDB'
            SQLTempDBLogDir       = 'G:\Logs'
            SQLBackupDir          = 'L:\Backup'
            UpdateEnabled         = 'True'
			SourcePath			  = 'C:\SQLServer_13.0_Full'
            ForceReboot           = $false
            BrowserSvcStartupType = 'Automatic'
            PsDscRunAsCredential  = $DomainCreds

            DependsOn             = '[WindowsFeature]ADPS'
        }
		
		 xSqlLogin AddDomainAdminAccountToSysadminServerRole
        {
            Name = $DomainCreds.UserName
            LoginType = "WindowsUser"
            ServerRoles = "sysadmin"
            Enabled = $true
            Credential = $Admincreds
            DependsOn = "[xComputer]DomainJoin"
        }



        xSqlLogin AddSqlServerServiceAccountToSysadminServerRole
        {
            Name = $SQLCreds.UserName
            LoginType = "WindowsUser"
            ServerRoles = "sysadmin"
            Enabled = $true
            Credential = $Admincreds

        }
        
        xSqlTsqlEndpoint AddSqlServerEndpoint
        {
            InstanceName = "WK01"
            PortNumber = $DatabaseEnginePort
            SqlAdministratorCredential = $Admincreds
            DependsOn = "[xSqlLogin]AddSqlServerServiceAccountToSysadminServerRole"
        }

        xSQLServerStorageSettings AddSQLServerStorageSettings
        {
            InstanceName = "WK01"
            OptimizationType = $WorkloadType
            DependsOn = "[xSqlTsqlEndpoint]AddSqlServerEndpoint"
        }

        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }

    }
}
function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}

