﻿#
# Copyright="© Microsoft Corporation. All rights reserved."
#

configuration PrepSQLOS
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [UInt32]$NumberOfDisks,

        [Parameter(Mandatory)]
        [String]$WorkloadType,

        [String]$DomainNetbiosName=(Get-NetBIOSName -DomainName $DomainName),

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

  	wusa /uninstall /kb:3186539  /quiet /norestart
	$source = "http://download.microsoft.com/download/F/9/4/F942F07D-F26F-4F30-B4E3-EBD54FABA377/NDP462-KB3151800-x86-x64-AllOS-ENU.exe"
	$dest = "C:\WindowsAzure\NDP462-KB3151800-x86-x64-AllOS-ENU.exe"
	Invoke-WebRequest $source -OutFile $dest
	$proc = Start-Process -FilePath "C:\WindowsAzure\NDP462-KB3151800-x86-x64-AllOS-ENU.exe" -ArgumentList "/quiet /norestart /log C:\WindowsAzure\NDP462-KB3151800-x86-x64-AllOS-ENU_install.log" -PassThru -Wait
	Import-DSCResource -Module xSystemSecurity -Name xIEEsc
    Import-DscResource -ModuleName xComputerManagement,CDisk,xActiveDirectory,XDisk,xSql, xSQLServer, xSQLps,xNetworking
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)


    $RebootVirtualMachine = $false

    if ($DomainName)
    {
        $RebootVirtualMachine = $true
    }

    #Finding the next avaiable disk letter for Add disk

		

	WaitForSqlSetup
	Node localhost
    {

        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
        }

        xWaitforDisk Disk3
        {
             DiskNumber = 3
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart LogDisk
        {
            DiskNumber = 3
            DriveLetter = "G"
        }

		 xWaitforDisk Disk4
        {
             DiskNumber = 4
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart BackupDisk
        {
            DiskNumber = 4
            DriveLetter = "H"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }

        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
	        DependsOn = "[WindowsFeature]ADPS"
        }
        
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
	        DependsOn = "[xWaitForADDomain]DscForestWait"
        }

	    File DataFolder
		{
            Type = "Directory"
            DestinationPath = "F:\DATA"
            Ensure = "Present"
			DependsOn = "[xWaitforDisk]Disk2"
        }
		
		File LogFolder
		{
            Type = "Directory"
            DestinationPath = "G:\LOG"
            Ensure = "Present"
			DependsOn = "[xWaitforDisk]Disk3"
        }
		
		File BackupFolder
    	{
            Type = "Directory"
            DestinationPath = "H:\Backup"
            Ensure = "Present"
			DependsOn = "[xWaitforDisk]Disk4"
        }
		
		xIEEsc EnableIEEscAdmin

		{

			IsEnabled = $False

			UserRole  = "Administrators"

		}

		xIEEsc EnableIEEscUser

		{

			IsEnabled = $True

			UserRole  = "Users"

		}
		
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }

    }
}
function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}

