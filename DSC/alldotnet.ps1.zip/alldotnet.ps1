Configuration InstallDotnet
{
  param ($MachineName)

  	wusa /uninstall /kb:3186539  /quiet /norestart
	$source = "http://download.microsoft.com/download/F/9/4/F942F07D-F26F-4F30-B4E3-EBD54FABA377/NDP462-KB3151800-x86-x64-AllOS-ENU.exe"
	$dest = "C:\WindowsAzure\NDP462-KB3151800-x86-x64-AllOS-ENU.exe"
	Invoke-WebRequest $source -OutFile $dest
	$proc = Start-Process -FilePath "C:\WindowsAzure\NDP462-KB3151800-x86-x64-AllOS-ENU.exe" -ArgumentList "/quiet /norestart /log C:\WindowsAzure\NDP462-KB3151800-x86-x64-AllOS-ENU_install.log" -PassThru -Wait
    $RebootVirtualMachine = $false
	Import-DSCResource -Module xSystemSecurity -Name xIEEsc
 
  Node $MachineName
  {
  	xIEEsc EnableIEEscAdmin

	{

		IsEnabled = $False

		UserRole  = "Administrators"

	}

	xIEEsc EnableIEEscUser

	{

		IsEnabled = $True

		UserRole  = "Users"

	}

	LocalConfigurationManager 
	{
		RebootNodeIfNeeded = $true
	}
  }
} 